create table junction1(
passenger_id int primary key,
passenger_name varchar(100),
passenger_department varchar(200),
contact_no int,
place varchar(100)
);
select * from junction1;
insert into junction1 values 
(101,'deepika','1stclass',1090706060,'trichy'),
(102,'mathan','sleeper',1350705967,'perambalur'),
(103,'sheela','1stclass',1095286060,'chitambaram'),
(104,'gopinath','1stclass',1093575680,'trichy'),
(105,'jega','sleeper',1024687690,'trichy'),
(106,'reenu','1stclass',1095587960,'perambalur'),
(107,'kamesh','sleeper',1092446760,'trichy'),
(108,'deepthi','1stclass',1090706696,'vayalur');
select * from junction1;
create table junction2(
passenger_id int primary key,
passenger_name varchar(100),
passenger_department varchar(200),
contact_no int(100),
place varchar(100)
);
select * from junction2;
insert into junction2 values 
(111,'ram','sleeper',1035546640,'pudukkottai'),
(115,'shiyam','sleeper',1344445967,'thanjavur'),
(117,'leela','1stclass',1095277770,'ramnad'),
(110,'karthik','1stclass',1345575680,'trichy'),
(118,'hari','sleeper',1067467690,'pudukkottai'),
(119,'reenu','1stclass',1645587960,'ramnad'),
(113,'nivash','sleeper',104566760,'trichy'),
(112,'deepak','sleeper',1095677696,'ramnad');
select * from junction2;
select * from junction1 where passenger_name like 'g%';
select * from junction1 where passenger_name like '%h';
select * from junction2 where passenger_name like '%i%';
select * from junction1 where passenger_name like '___i';
select*from junction1 order by passenger_name ASC ;
select*from junction2 order by passenger_name DESC ;
select passenger_name,passenger_name as traveller_name from junction1;
select distinct place from junction1;
select position('D' in lower(passenger_name)) from junction1 where passenger_name='deepthi';
select left(passenger_name, 6) from junction2;
select rtrim(passenger_name) from junction1;
select ucase(passenger_name) as traveller_name from junction2 ;
select lcase(passenger_name) as traveller_name from junction1 ;
SELECT DISTINCT TRIM(place) AS place, LENGTH(TRIM(place)) AS place_Length
FROM junction1
ORDER BY place_Length DESC, place;
SELECT DISTINCT LTRIM(passenger_department) FROM junction1;
SELECT REPLACE(passenger_name, 'a', 'A') AS Modified_passenger_Name FROM junction1;
SELECT *FROM junction1 WHERE passenger_name IN ('deepthi', 'nivash');
SELECT CONCAT(passenger_name, ' ') AS COMPLETE_NAME FROM junction2;
SELECT *FROM junction1 WHERE  passenger_name NOT IN ('hari', 'leela');
SELECT *FROM junction2 WHERE place = 'trichy';
SELECT COUNT(*) AS trichy_Count FROM junction1 WHERE place = 'trichy';
SELECT passenger_department, COUNT(*) AS passenger_Count FROM junction2 GROUP BY passenger_department  ORDER BY passenger_Count DESC;
SELECT passenger_name, passenger_department, COUNT(*) as duplicate_count FROM junction1 GROUP BY passenger_name, passenger_department
HAVING COUNT(*) > 1;
SELECT *
FROM (
    SELECT *, ROW_NUMBER() OVER (ORDER BY passenger_id) AS row_num
    FROM junction1
) AS numbered_rows
WHERE row_num % 2 = 1;
SELECT NOW() AS current_datetime;
SELECT *FROM junction1 ORDER BY passenger_id LIMIT 10;
SELECT *
FROM (
    SELECT *, ROW_NUMBER() OVER (ORDER BY passenger_id) AS row_num
    FROM junction2
) AS numbered_rows
WHERE row_num % 2 = 0;
select  junction1.passenger_name,junction1.passenger_id,junction2.passenger_name,junction2.passenger_id 
from junction1 right join junction2 on junction1.passenger_id=junction2.passenger_id order by junction1.passenger_id;
SELECT place FROM (
    SELECT DISTINCT place
    FROM junction1
    ORDER BY place DESC
    LIMIT 5
) AS top_3 ORDER BY place LIMIT 3;
SELECT MAX(place) AS SecondHighestSalary FROM junction1 WHERE place < (SELECT MAX(place) FROM junction1);
select  junction1.passenger_name,junction1.passenger_id,junction2.passenger_name,junction2.passenger_id 
from junction1 left join junction2 on junction1.passenger_id=junction2.passenger_id order by junction1.passenger_id;
select min(place) from junction1;
select max(place) from junction2;
select avg(place) from junction2;
desc junction1;
use studentdb1;
show tables;
update junction1 set passenger_name='shesha' where passenger_id=102;
DELETE FROM junction1 WHERE passenger_id = 102 ;
truncate table junction1;
drop table junction1;
alter table junction1 rename to mainjunction;

